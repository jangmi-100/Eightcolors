/*package com.springbootfinal.app.controller;

public class SocialController {

}
*/