/*package com.springbootfinal.app.custom;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.user.OAuth2User;

import com.springbootfinal.app.domain.Member;

public class CustomOAuth2User implements OAuth2User {

    private final OAuth2User oAuth2User;
    private final String providerId;
    private final String name;
    private final Member member;  // 추가된 Member 객체

    // Member 객체와 attributes를 받는 생성자
    public CustomOAuth2User(Member member,
    		OAuth2User oAuth2User,
    		Map<String, Object> attributes) {
        this.member = member;  // Member 객체를 저장
        this.oAuth2User = oAuth2User;  // OAuth2User는 이미 생성되어 있음
        this.providerId = (String) attributes.get("id");  // attributes에서 providerId 추출
        this.name = (String) attributes.get("name");  // attributes에서 이름 추출
    }

    @Override
    public Map<String, Object> getAttributes() {
        return oAuth2User.getAttributes();  // 기존 OAuth2User의 속성 반환
    }

    @Override
    public String getName() {
        return this.name;
    }

    public String getProviderId() {
        return this.providerId;
    }

    public Member getMember() {
        return this.member;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // 사용자의 권한 반환 (예: ROLE_USER)
        return Collections.singletonList(new SimpleGrantedAuthority("ROLE_USER"));
    }
}
*/