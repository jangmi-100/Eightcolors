/*package com.springbootfinal.app.custom;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CustomOAuth2LoginSuccessHandler extends SimpleUrlAuthenticationSuccessHandler {

    @Override
    public void onAuthenticationSuccess(
    		HttpServletRequest request,
    		HttpServletResponse response,
            Authentication authentication) throws IOException, ServletException {
        OAuth2User oAuth2User = (OAuth2User) authentication.getPrincipal();
        
        // 소셜 로그인 후 사용자 정보 처리 (예: DB에 사용자 저장)
        String providerId = (String) oAuth2User.getAttributes().get("id");  // 소셜 로그인 제공자의 고유 ID 가져오기
        
        // 예: 소셜 로그인 사용자 정보로 DB에 회원 저장
        // socialMemberService.saveOrUpdateSocialMember(providerId, oAuth2User.getAttributes());

        // 로그인 성공 후 리디렉션할 URL을 설정
        super.onAuthenticationSuccess(request, response, authentication);  // 기본 로그인 성공 처리
    }
}

*/