/*package com.springbootfinal.app.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.springbootfinal.app.domain.SocialMember;

@Mapper
public interface SocialMemberMapper {

    // 소셜 회원 정보 저장
    void insertSocialMember(
    		@Param("memberId") int memberId, 
    		@Param("provider") String provider, 
    		@Param("providerId") String providerId);
    
 // 소셜 로그인 정보 조회
    SocialMember findByProviderAndProviderId(
    		@Param("provider") String provider, 
            @Param("providerId") String providerId);
}
*/