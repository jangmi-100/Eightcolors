/*package com.springbootfinal.app.custom;

import java.io.IOException;

import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class CustomOAuth2LoginFailureHandler extends SimpleUrlAuthenticationFailureHandler {

    @Override
    public void onAuthenticationFailure(
    		HttpServletRequest request, 
    		HttpServletResponse response,
            AuthenticationException exception) throws IOException, ServletException {
        // 로그인 실패 후 처리 (예: 실패 메시지 표시 또는 로그인 페이지로 리디렉션)
        // 예를 들어, 실패 이유를 로그로 기록하거나 사용자에게 오류 메시지를 보여줄 수 있습니다.

        super.onAuthenticationFailure(request, response, exception);
    }
}

*/