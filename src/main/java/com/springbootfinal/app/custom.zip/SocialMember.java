/*package com.springbootfinal.app.domain;

import java.sql.Timestamp;

import jakarta.persistence.PrePersist;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class SocialMember {

    private int id;             // 소셜 회원 고유 ID (자동 생성)
    private int memberId;       // `member` 테이블의 `power`와 연결된 외래 키
    private String provider;    // 소셜 로그인 제공자 (google, naver, kakao 등)
    private String providerId;  // 소셜 로그인 사용자 고유 ID
    private Timestamp createdAt; // 소셜 회원 가입일 (선택 사항)

    // 필요한 경우, 소셜 회원 가입 시 생성일을 자동으로 설정할 수 있습니다.
    @PrePersist
    public void prePersist() {
        if (createdAt == null) {
            this.createdAt = 
            		new Timestamp(System.currentTimeMillis());
        }
    }
}

*/