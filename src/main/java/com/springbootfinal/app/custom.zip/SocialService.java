/*package com.springbootfinal.app.service;

import java.sql.Timestamp;
import java.util.Map;

import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import com.springbootfinal.app.custom.CustomOAuth2User;
import com.springbootfinal.app.domain.Member;
import com.springbootfinal.app.mapper.MemberMapper;
import com.springbootfinal.app.mapper.SocialMemberMapper;

@Service
public class SocialService implements OAuth2UserService<OAuth2UserRequest, OAuth2User> {

    private final MemberMapper memberMapper;  // MyBatis에서 사용
    private final SocialMemberMapper socialMemberMapper;  // 소셜 회원 정보를 저장하는 Mapper

    public SocialService(MemberMapper memberMapper, SocialMemberMapper socialMemberMapper) {
        this.memberMapper = memberMapper;
        this.socialMemberMapper = socialMemberMapper;
    }

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
        // DefaultOAuth2UserService를 통해 OAuth2User를 생성
        OAuth2User oAuth2User = new DefaultOAuth2UserService().loadUser(userRequest);
        String provider = userRequest.getClientRegistration().getRegistrationId();  // google, naver, kakao
        Map<String, Object> attributes = oAuth2User.getAttributes();

        // 사용자 정보 추출
        String providerId = getProviderId(provider, attributes);
        String name = getName(provider, attributes);
        String email = getEmail(provider, attributes);

        // 회원 조회
        Member member = memberMapper.getMember(email);  // 이메일로 회원 검색

        if (member == null) {
            // 새로운 회원 등록
            member = new Member();
            member.setId(email);
            member.setName(name);
            member.setProvider(provider);
            member.setProviderId(providerId);
            member.setRegDate(new Timestamp(System.currentTimeMillis()));
            member.setPower(0);  // 기본 권한
            memberMapper.addMember(member);
        }

        // 소셜 회원 정보 저장 (소셜 로그인 후 회원 ID와 소셜 로그인 정보를 저장)
        socialMemberMapper.insertSocialMember(member.getPower(), provider, providerId);

        // CustomOAuth2User 생성 및 반환
        return new CustomOAuth2User(member, oAuth2User, attributes);  // CustomOAuth2User 생성
    }

    private String getProviderId(String provider, Map<String, Object> attributes) {
        if ("google".equals(provider)) {
            return (String) attributes.get("sub");
        } else if ("naver".equals(provider)) {
            Map<String, Object> response = (Map<String, Object>) attributes.get("response");
            return (String) response.get("id");
        } else if ("kakao".equals(provider)) {
            return String.valueOf(attributes.get("id"));
        }
        throw new OAuth2AuthenticationException("Unknown provider: " + provider);
    }

    private String getName(String provider, Map<String, Object> attributes) {
        if ("google".equals(provider)) {
            return (String) attributes.get("name");
        } else if ("naver".equals(provider)) {
            Map<String, Object> response = (Map<String, Object>) attributes.get("response");
            return (String) response.get("name");
        } else if ("kakao".equals(provider)) {
            Map<String, Object> kakaoAccount = (Map<String, Object>) attributes.get("kakao_account");
            Map<String, Object> profile = (Map<String, Object>) kakaoAccount.get("profile");
            return (String) profile.get("nickname");
        }
        throw new OAuth2AuthenticationException("Unknown provider: " + provider);
    }

    private String getEmail(String provider, Map<String, Object> attributes) {
        if ("google".equals(provider)) {
            return (String) attributes.get("email");
        } else if ("naver".equals(provider)) {
            Map<String, Object> response = (Map<String, Object>) attributes.get("response");
            return (String) response.get("email");
        } else if ("kakao".equals(provider)) {
            Map<String, Object> kakaoAccount = (Map<String, Object>) attributes.get("kakao_account");
            return (String) kakaoAccount.get("email");
        }
        throw new OAuth2AuthenticationException("Unknown provider: " + provider);
    }
}
*/